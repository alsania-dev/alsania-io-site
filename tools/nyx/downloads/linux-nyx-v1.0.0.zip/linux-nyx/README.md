# NYX MCP - Linux Setup

## Quick Start

1. **Make scripts executable**:
   ```bash
   chmod +x linux-setup.sh
   ```
2. **Run setup**:
   ```bash
   ./linux-setup.sh
   ```
3. **Install Chrome Extension**:
   - Open Chrome/Chromium, go to `chrome://extensions/`
   - Enable "Developer mode" (top-right toggle)
   - Click "Load unpacked"
   - Select the `chrome-extension` folder from this package
4. **Start NYX**:
   ```bash
   cd ~/Desktop/nyx
   ./nyx-start.sh
   ```
5. **Connect**: Click the NYX extension icon in Chrome

## Detailed Steps

### Prerequisites
- **Chrome or Chromium** browser
- **Node.js 18+** (will be checked during setup)
- **Standard Linux utilities** (sed, curl, etc.)

### What the Setup Script Does
1. **Checks requirements** (Chrome/Chromium, Node.js)
2. **Creates `~/Desktop/nyx`** directory
3. **Sets up configuration** with restricted filesystem access
4. **Creates start/stop scripts**
5. **Creates desktop entry** (`nyx.desktop`) for application menu

### Running the Server
- **Terminal method**:
   ```bash
   cd ~/Desktop/nyx
   ./nyx-start.sh
   ```
- **Stop server**:
   ```bash
   cd ~/Desktop/nyx
   ./nyx-stop.sh
   ```
- **Or use desktop entry**: Copy `nyx.desktop` to `~/.local/share/applications/`

### Security
- Filesystem access is **restricted** to your `~/Desktop/nyx` directory only
- No access to other parts of your system
- All MCP servers run with minimal permissions

## Troubleshooting

### Distribution-Specific Notes

#### Ubuntu/Debian:
```bash
sudo apt update
sudo apt install chromium-browser nodejs npm
```

#### Fedora:
```bash
sudo dnf install chromium nodejs
```

#### Arch:
```bash
sudo pacman -S chromium nodejs npm
```

### Node.js Installation (Recommended)
Use **nvm** for best results:
```bash
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.7/install.sh | bash
source ~/.bashrc
nvm install 20
nvm use 20
```

### Chrome/Chromium not found
Install via your package manager or download from [google.com/chrome](https://www.google.com/chrome/)

### Permission Issues
If scripts aren't executable:
```bash
chmod +x linux-setup.sh nyx-start.sh nyx-stop.sh
```

## Manual Commands

If scripts don't work, run manually:
```bash
cd ~/Desktop/nyx
npx -y @alsania-io/mcpnyx@latest --config config.json --outputTransport streamableHttp
```

## Desktop Integration

For application menu integration:
```bash
cp ~/Desktop/nyx/nyx.desktop ~/.local/share/applications/
```

Then search for "NYX MCP" in your application menu.

## Included Tools
- **Filesystem**: Access files in `~/Desktop/nyx`
- **Memory Cache**: Store and recall information
- **Playwright**: Browser automation
- **Desktop Commander**: System commands
- **Terminal Controller**: Terminal operations
- **Context7**: Documentation lookup
- **Sequential Thinking**: Problem-solving tool

## Support
For issues, contact the Alsania development team.

---
**NYX MCP** - Sovereign AI infrastructure
*Linux Package v1.0*
