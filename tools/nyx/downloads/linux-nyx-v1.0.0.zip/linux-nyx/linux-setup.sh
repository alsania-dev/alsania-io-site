#!/bin/bash

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${BLUE}==============================================${NC}"
echo -e "${BLUE}   NYX MCP Setup for Linux${NC}"
echo -e "${BLUE}==============================================${NC}"
echo

echo -e "${BLUE}1. Checking for Chrome/Chromium browser...${NC}"
if command -v google-chrome &> /dev/null; then
    echo -e "  ${GREEN}✓ Google Chrome detected${NC}"
elif command -v chromium-browser &> /dev/null; then
    echo -e "  ${GREEN}✓ Chromium browser detected${NC}"
elif command -v chrome &> /dev/null; then
    echo -e "  ${GREEN}✓ Chrome detected${NC}"
else
    echo -e "  ${YELLOW}⚠ Chrome/Chromium not found in PATH${NC}"
    echo -e "  Please install Chrome or Chromium first:"
    echo -e "  Ubuntu/Debian: sudo apt install chromium-browser"
    echo -e "  Fedora: sudo dnf install chromium"
    echo -e "  Arch: sudo pacman -S chromium"
    echo -e "  Or download from: https://www.google.com/chrome/"
    read -p "Press Enter to continue..."
fi

echo

echo -e "${BLUE}2. Installing NYX Chrome extension...${NC}"
echo -e "  Please follow these steps manually:"
echo -e "  1. Open Chrome/Chromium and go to: chrome://extensions/"
echo -e "  2. Enable \"Developer mode\" (top-right toggle)"
echo -e "  3. Click \"Load unpacked\""
echo -e "  4. Navigate to and select the \"chrome-extension\" folder in this package"

if [[ -d "chrome-extension" ]]; then
    echo -e "  ${GREEN}✓ Extension folder found in package${NC}"
else
    echo -e "  ${YELLOW}⚠ Extension folder not found in package${NC}"
    echo -e "  You may need to download it separately"
fi

echo

echo -e "${BLUE}3. Setting up NYX directory on Desktop...${NC}"
NYX_DIR="$HOME/Desktop/nyx"

if [[ ! -d "$NYX_DIR" ]]; then
    mkdir -p "$NYX_DIR"
    echo -e "  ${GREEN}✓ Created nyx directory: $NYX_DIR${NC}"
else
    echo -e "  ${GREEN}✓ NYX directory already exists: $NYX_DIR${NC}"
fi

echo

echo -e "${BLUE}4. Checking for Node.js and npm...${NC}"
if command -v node &> /dev/null; then
    NODE_VERSION=$(node --version | cut -d'v' -f2)
    MAJOR_VERSION=$(echo $NODE_VERSION | cut -d'.' -f1)
    if [[ $MAJOR_VERSION -ge 18 ]]; then
        echo -e "  ${GREEN}✓ Node.js $NODE_VERSION detected (18+ required)${NC}"
    else
        echo -e "  ${RED}❌ Node.js $NODE_VERSION detected (18+ required)${NC}"
        echo -e "  Please update Node.js:"
        echo -e "  Using nvm: nvm install 20 && nvm use 20"
        echo -e "  Or via package manager"
        read -p "Press Enter to continue..."
    fi
else
    echo -e "  ${RED}❌ Node.js not found. Please install Node.js 18+${NC}"
    echo -e "  Recommended: Install nvm, then Node.js 20:"
    echo -e "  curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.7/install.sh | bash"
    echo -e "  source ~/.bashrc"
    echo -e "  nvm install 20"
    echo -e "  nvm use 20"
    echo -e "  Or download from: https://nodejs.org/"
    read -p "Press Enter to continue..."
fi

if command -v npm &> /dev/null; then
    echo -e "  ${GREEN}✓ npm detected${NC}"
else
    echo -e "  ${YELLOW}⚠ npm not found (but Node.js may be installed)${NC}"
fi

echo

echo -e "${BLUE}5. Setting up configuration...${NC}"
if [[ ! -f "config.json" ]]; then
    echo -e "  ${RED}❌ config.json not found in package${NC}"
    echo -e "  Please ensure config.json exists in this directory"
    read -p "Press Enter to continue..."
    exit 1
fi

# Replace placeholder with absolute path
CONFIG_FILE="$NYX_DIR/config.json"
sed "s|NYX_DIR_PLACEHOLDER|$NYX_DIR|g" config.json > "$CONFIG_FILE"

echo -e "  ${GREEN}✓ Created config.json with absolute path: $NYX_DIR${NC}"
echo -e "  ${GREEN}✓ Filesystem access restricted to this directory only${NC}"

echo

echo -e "${BLUE}6. Creating start and stop scripts...${NC}"

# Create start script
cat > "$NYX_DIR/nyx-start.sh" << 'EOF'
#!/bin/bash

echo "==============================================