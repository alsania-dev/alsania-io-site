#!/bin/bash

chmod +x linux-setup.sh
chmod +x nyx-start.sh
chmod +x nyx-stop.sh

echo "All Linux scripts are now executable."
echo "Run ./linux-setup.sh to begin setup."
