#!/bin/bash

echo "=============================================="
echo "  NYX MCP Server - Linux (Package)"
echo "=============================================="
echo
echo "This is the packaged start script."
echo "Please run linux-setup.sh first to install NYX properly."
echo
echo "If you have already run linux-setup.sh:"
echo "1. The proper start script is at: ~/Desktop/nyx/nyx-start.sh"
echo "2. Run it from terminal: cd ~/Desktop/nyx && ./nyx-start.sh"
echo
echo "If you haven't run setup:"
echo "1. Open terminal"
echo "2. Navigate to this directory"
echo "3. Run: chmod +x linux-setup.sh && ./linux-setup.sh"
echo
read -p "Press Enter to close this terminal..."
