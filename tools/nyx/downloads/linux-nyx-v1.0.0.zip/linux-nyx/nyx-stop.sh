#!/bin/bash

echo "=============================================="
echo "  NYX MCP Server - Stop Script (Package)"
echo "=============================================="
echo
echo "This is the packaged stop script."
echo "After running linux-setup.sh, the proper stop script"
echo "will be at: ~/Desktop/nyx/nyx-stop.sh"
echo
echo "To stop NYX after setup:"
echo "1. Run: cd ~/Desktop/nyx && ./nyx-stop.sh"
echo "2. Or run: pkill -f \"npx.*mcpnyx\""
echo
read -p "Press Enter to close this terminal..."
