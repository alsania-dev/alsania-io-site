import { logMessage } from '../utils/helpers';

/**
 * Insert tool result text into Claude's chat input
 */
export function insertToolResultToChatInput(text) {
    try {
        // Find Claude's textarea
        const textarea = document.querySelector('textarea[placeholder*="Reply"]') ||
                        document.querySelector('textarea[placeholder*="Talk"]') ||
                        document.querySelector('div[contenteditable="true"]');

        if (!textarea) {
            logMessage('Could not find Claude input element');
            return false;
        }

        if (textarea.tagName === 'TEXTAREA') {
            // Standard textarea
            textarea.value = text;
            textarea.dispatchEvent(new Event('input', { bubbles: true }));
            textarea.dispatchEvent(new Event('change', { bubbles: true }));
        } else {
            // ContentEditable div
            textarea.textContent = text;
            textarea.dispatchEvent(new Event('input', { bubbles: true }));
        }

        // Focus the input
        textarea.focus();

        logMessage('Successfully inserted text into Claude input');
        return true;
    } catch (error) {
        logMessage(`Error inserting text into Claude input: ${error}`);
        return false;
    }
}

/**
 * Attach file to Claude's chat input
 */
export async function attachFileToChatInput(file) {
    try {
        logMessage(`Attempting to attach file to Claude: ${file.name}`);

        // Find the file input (usually hidden)
        const fileInput = document.querySelector('input[type="file"]');

        if (!fileInput) {
            logMessage('Could not find file input for Claude');
            return false;
        }

        // Create a DataTransfer to simulate file selection
        const dataTransfer = new DataTransfer();
        dataTransfer.items.add(file);
        fileInput.files = dataTransfer.files;

        // Trigger change event
        fileInput.dispatchEvent(new Event('change', { bubbles: true }));

        logMessage(`Successfully attached file to Claude: ${file.name}`);
        return true;
    } catch (error) {
        logMessage(`Error attaching file to Claude: ${error}`);
        return false;
    }
}

/**
 * Submit Claude's chat input
 */
export async function submitChatInput() {
    try {
        // Find the submit button
        const submitButton = document.querySelector('button[aria-label*="Send"]') ||
                           document.querySelector('button[type="submit"]') ||
                           Array.from(document.querySelectorAll('button')).find(
                               btn => btn.textContent.trim().toLowerCase() === 'send' ||
                                      btn.querySelector('svg') // Send button usually has an icon
                           );

        if (!submitButton) {
            logMessage('Could not find Claude submit button');
            return false;
        }

        // Check if button is disabled
        if (submitButton.disabled || submitButton.hasAttribute('disabled')) {
            logMessage('Claude submit button is disabled');
            return false;
        }

        submitButton.click();
        logMessage('Successfully clicked Claude submit button');
        return true;
    } catch (error) {
        logMessage(`Error submitting Claude chat: ${error}`);
        return false;
    }
}
