# NYX MCP - macOS Setup

## Quick Start

1. **Make scripts executable**:
   ```bash
   chmod +x mac-setup.sh
   ```
2. **Run setup**:
   ```bash
   ./mac-setup.sh
   ```
3. **Install Chrome Extension**:
   - Open Chrome, go to `chrome://extensions/`
   - Enable "Developer mode" (top-right toggle)
   - Click "Load unpacked"
   - Select the `chrome-extension` folder from this package
4. **Start NYX**: Double-click `nyx-start.command` in `~/Desktop/nyx/`
5. **Connect**: Click the NYX extension icon in Chrome

## Detailed Steps

### Prerequisites
- **Google Chrome** (or Chromium)
- **Node.js 18+** (will be checked during setup)
- **Terminal access** (Applications → Utilities → Terminal)

### What the Setup Script Does
1. **Checks requirements** (Chrome, Node.js)
2. **Creates `~/Desktop/nyx`** directory
3. **Sets up configuration** with restricted filesystem access
4. **Creates start/stop scripts** (`.command` files for easy clicking)
5. **Provides launcher instructions**

### Running the Server
- **Start**: Double-click `nyx-start.command` in `~/Desktop/nyx/`
- **Stop**: Double-click `nyx-stop.command` in `~/Desktop/nyx/`
- **Or use terminal**: `cd ~/Desktop/nyx && ./nyx-start.sh`

### Security
- Filesystem access is **restricted** to your `~/Desktop/nyx` directory only
- No access to other parts of your system
- All MCP servers run with minimal permissions

## Troubleshooting

### "Permission denied" when running setup
```bash
chmod +x mac-setup.sh
./mac-setup.sh
```

If you get security warnings about unidentified developer:
1. Right-click `mac-setup.sh` → Open
2. Click "Open" in the security dialog

### Node.js not found
Install via Homebrew:
```bash
brew install node
```

Or download from [nodejs.org](https://nodejs.org/)

### Chrome Extension Won't Load
- Ensure Chrome is installed (`/Applications/Google Chrome.app`)
- Enable "Developer mode" in `chrome://extensions/`
- Select the `chrome-extension` **folder** (not a file inside it)

## Manual Commands

If scripts don't work, run manually:
```bash
cd ~/Desktop/nyx
npx -y @alsania-io/mcpnyx@latest --config config.json --outputTransport streamableHttp
```

## Included Tools
- **Filesystem**: Access files in `~/Desktop/nyx`
- **Memory Cache**: Store and recall information
- **Playwright**: Browser automation
- **Desktop Commander**: System commands
- **Terminal Controller**: Terminal operations
- **Context7**: Documentation lookup
- **Sequential Thinking**: Problem-solving tool

## AppleScript Launcher

For easier launching, run:
```bash
open ~/Desktop/nyx/Create\ Desktop\ Launcher.applescript
```

This will create a dialog with setup completion instructions.

## Support
For issues, contact the Alsania development team.

---
**NYX MCP** - Sovereign AI infrastructure
*macOS Package v1.0*
