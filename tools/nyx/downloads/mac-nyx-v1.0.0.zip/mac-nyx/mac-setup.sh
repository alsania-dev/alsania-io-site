#!/bin/bash

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${BLUE}==============================================${NC}"
echo -e "${BLUE}   NYX MCP Setup for macOS${NC}"
echo -e "${BLUE}==============================================${NC}"
echo

echo -e "${BLUE}1. Checking for Chrome browser...${NC}"
if [[ -d "/Applications/Google Chrome.app" ]]; then
    echo -e "  ${GREEN}✓ Chrome detected${NC}"
else
    echo -e "  ${YELLOW}⚠ Chrome not found in Applications${NC}"
    echo -e "  Please install Chrome first:"
    echo -e "  https://www.google.com/chrome/"
    echo -e "\n  Or install via Homebrew:\n  brew install --cask google-chrome"
    read -p "Press Enter to continue..."
fi

echo

echo -e "${BLUE}2. Installing NYX Chrome extension...${NC}"
echo -e "  Please follow these steps manually:"
echo -e "  1. Open Chrome and go to: chrome://extensions/"
echo -e "  2. Enable \"Developer mode\" (top-right toggle)"
echo -e "  3. Click \"Load unpacked\""
echo -e "  4. Navigate to and select the \"chrome-extension\" folder in this package"

if [[ -d "chrome-extension" ]]; then
    echo -e "  ${GREEN}✓ Extension folder found in package${NC}"
else
    echo -e "  ${YELLOW}⚠ Extension folder not found in package${NC}"
    echo -e "  You may need to download it separately"
fi

echo

echo -e "${BLUE}3. Setting up NYX directory on Desktop...${NC}"
NYX_DIR="$HOME/Desktop/nyx"

if [[ ! -d "$NYX_DIR" ]]; then
    mkdir -p "$NYX_DIR"
    echo -e "  ${GREEN}✓ Created nyx directory: $NYX_DIR${NC}"
else
    echo -e "  ${GREEN}✓ NYX directory already exists: $NYX_DIR${NC}"
fi

echo

echo -e "${BLUE}4. Checking for Node.js and npm...${NC}"
if command -v node &> /dev/null; then
    NODE_VERSION=$(node --version | cut -d'v' -f2)
    MAJOR_VERSION=$(echo $NODE_VERSION | cut -d'.' -f1)
    if [[ $MAJOR_VERSION -ge 18 ]]; then
        echo -e "  ${GREEN}✓ Node.js $NODE_VERSION detected (18+ required)${NC}"
    else
        echo -e "  ${RED}❌ Node.js $NODE_VERSION detected (18+ required)${NC}"
        echo -e "  Please update Node.js:\n  brew update && brew upgrade node"
        read -p "Press Enter to continue..."
    fi
else
    echo -e "  ${RED}❌ Node.js not found. Please install Node.js 18+${NC}"
    echo -e "  Install via Homebrew:\n  brew install node"
    echo -e "  Or download from: https://nodejs.org/"
    read -p "Press Enter to continue..."
fi

if command -v npm &> /dev/null; then
    echo -e "  ${GREEN}✓ npm detected${NC}"
else
    echo -e "  ${YELLOW}⚠ npm not found (but Node.js may be installed)${NC}"
fi

echo

echo -e "${BLUE}5. Setting up configuration...${NC}"
if [[ ! -f "config.json" ]]; then
    echo -e "  ${RED}❌ config.json not found in package${NC}"
    echo -e "  Please ensure config.json exists in this directory"
    read -p "Press Enter to continue..."
    exit 1
fi

# Replace placeholder with absolute path
CONFIG_FILE="$NYX_DIR/config.json"
sed "s|NYX_DIR_PLACEHOLDER|$NYX_DIR|g" config.json > "$CONFIG_FILE"

echo -e "  ${GREEN}✓ Created config.json with absolute path: $NYX_DIR${NC}"
echo -e "  ${GREEN}✓ Filesystem access restricted to this directory only${NC}"

echo

echo -e "${BLUE}6. Creating start and stop scripts...${NC}"

# Create start script
cat > "$NYX_DIR/nyx-start.command" << 'EOF'
#!/bin/bash

echo "=============================================="
echo "  NYX MCP Server - macOS"
echo "=============================================="
echo
echo "Starting NYX MCP Server..."
echo "Server will run in this window."
echo "Press Ctrl+C to stop the server."
echo

cd "$(dirname "$0")"

# Check if config exists
if [[ ! -f "config.json" ]]; then
    echo "❌ ERROR: config.json not found in current directory"
    echo "Please run mac-setup.sh first to set up NYX"
    read -p "Press Enter to exit..."
    exit 1
fi

# Check Node.js
if ! command -v node &> /dev/null; then
    echo "❌ ERROR: Node.js not found. Please install Node.js 18+"
    echo "Install via: brew install node"
    read -p "Press Enter to exit..."
    exit 1
fi

echo "✓ Node.js detected"
echo "✓ Starting NYX MCP Server..."
echo
echo "=============================================="
echo "  SERVER LOGS START"
echo "=============================================="
echo

npx -y @alsania-io/mcpnyx@latest --config "config.json" --outputTransport streamableHttp

echo
echo "=============================================="
echo "  SERVER STOPPED"
echo "=============================================="
echo
read -p "Press Enter to close this window..."
EOF

chmod +x "$NYX_DIR/nyx-start.command"
echo -e "  ${GREEN}✓ Created nyx-start.command${NC}"

# Create stop script
cat > "$NYX_DIR/nyx-stop.command" << 'EOF'
#!/bin/bash

echo "=============================================="
echo "  NYX MCP Server - Stop Script"
echo "=============================================="
echo
echo "Stopping all NYX MCP servers..."
echo

pkill -f "npx.*mcpnyx" 2>/dev/null
if [[ $? -eq 0 ]]; then
    echo "✓ Stopped NYX MCP server processes"
else
    echo "✓ No running NYX MCP processes found"
fi

echo
echo "To start NYX again, double-click nyx-start.command"
echo
read -p "Press Enter to close this window..."
EOF

chmod +x "$NYX_DIR/nyx-stop.command"
echo -e "  ${GREEN}✓ Created nyx-stop.command${NC}"

# Make desktop scripts executable
chmod +x "$NYX_DIR/nyx-start.command"
chmod +x "$NYX_DIR/nyx-stop.command"

echo

echo -e "${BLUE}7. Creating desktop launcher...${NC}"
# Create a simple AppleScript to create a clickable icon
cat > "$NYX_DIR/Create Desktop Launcher.applescript" << 'EOF'
tell application "Finder"
    set desktopPath to path to desktop folder as string
    set nyxFolder to desktopPath & "nyx"
    set startScript to nyxFolder & ":nyx-start.command"
    
    -- Make the script executable
    do shell script "chmod +x " & quoted form of POSIX path of startScript
    
    display dialog "Setup complete!" & return & return & 
    "To start NYX:" & return & 
    "1. Open the 'nyx' folder on your Desktop" & return & 
    "2. Double-click 'nyx-start.command'" & return & return & 
    "The server will start in a new terminal window." buttons {"OK"} default button 1
end tell
EOF

echo -e "  ${GREEN}✓ Created desktop launcher instructions${NC}"

echo

echo -e "${BLUE}==============================================${NC}"
echo -e "${BLUE}   SETUP COMPLETE${NC}"
echo -e "${BLUE}==============================================${NC}"
echo
echo -e "${GREEN}✓ Setup completed successfully!${NC}"
echo
echo "Next steps:"
echo "1. Install the NYX Chrome extension (see step 2)"
echo "2. Open Terminal and run:"
echo "   open ~/Desktop/nyx/Create\ Desktop\ Launcher.applescript"
echo "3. Follow the instructions to create the launcher"
echo "4. Or manually double-click ~/Desktop/nyx/nyx-start.command"
echo
echo "Security configuration:"
echo "• Filesystem access restricted to: $NYX_DIR"
echo "• Desktop-commander uses allowed directories only"
echo "• All MCP servers run with minimal permissions"
echo
echo "For manual start: Double-click nyx-start.command in Desktop/nyx/"
echo "For manual stop: Double-click nyx-stop.command in Desktop/nyx/"
echo

# Make the setup script executable
chmod +x "$0"

echo "Setup script is now executable."
echo "You can run it again if needed."
echo
read -p "Press Enter to finish setup..."
