#!/bin/bash

chmod +x mac-setup.sh
chmod +x nyx-start.command
chmod +x nyx-stop.command

echo "All macOS scripts are now executable."
echo "Run ./mac-setup.sh to begin setup."
