import { BaseAdapter } from './common';
import { logMessage } from '../utils/helpers';
import { insertToolResultToChatInput, attachFileToChatInput, submitChatInput } from '../components/websites/claude';
import { SidebarManager } from '../components/sidebar';
import { initClaudeComponents } from './adaptercomponents/claude';

export class ClaudeAdapter extends BaseAdapter {
    constructor() {
        super();
        this.name = 'Claude';
        this.hostname = ['claude.ai'];
        this.lastUrl = '';
        this.urlCheckInterval = null;
        this.sidebarManager = SidebarManager.getInstance('claude');
        logMessage('Created Claude sidebar manager instance');
    }

    initializeSidebarManager() {
        this.sidebarManager.initialize();
    }

    initializeObserver(forceReset = false) {
        initClaudeComponents();

        if (!this.urlCheckInterval) {
            this.lastUrl = window.location.href;
            this.urlCheckInterval = window.setInterval(() => {
                const currentUrl = window.location.href;
                if (currentUrl !== this.lastUrl) {
                    logMessage(`Claude URL changed from ${this.lastUrl} to ${currentUrl}`);
                    this.lastUrl = currentUrl;
                    initClaudeComponents();
                    this.checkCurrentUrl();
                }
            }, 1000);
        }
    }

    cleanup() {
        if (this.urlCheckInterval) {
            window.clearInterval(this.urlCheckInterval);
            this.urlCheckInterval = null;
        }
        super.cleanup();
    }

    insertTextIntoInput(text) {
        insertToolResultToChatInput(text);
        logMessage(`Inserted text into Claude input: ${text.substring(0, 20)}...`);
    }

    triggerSubmission() {
        submitChatInput()
            .then((success) => {
                logMessage(`Triggered Claude form submission: ${success ? 'success' : 'failed'}`);
            })
            .catch((error) => {
                logMessage(`Error triggering Claude form submission: ${error}`);
            });
    }

    supportsFileUpload() {
        return true;
    }

    async attachFile(file) {
        try {
            const result = await attachFileToChatInput(file);
            return result;
        } catch (error) {
            const errorMessage = error instanceof Error ? error.message : String(error);
            logMessage(`Error in adapter when attaching file to Claude input: ${errorMessage}`);
            console.error('Error in adapter when attaching file to Claude input:', error);
            return false;
        }
    }

    forceFullScan() {
        logMessage('Forcing full document scan for Claude');
    }

    checkCurrentUrl() {
        const currentUrl = window.location.href;
        logMessage(`Checking current Claude URL: ${currentUrl}`);

        if (this.sidebarManager && !this.sidebarManager.getIsVisible()) {
            logMessage('Showing sidebar for Claude URL');
            this.sidebarManager.showWithToolOutputs();
        }
    }
}
