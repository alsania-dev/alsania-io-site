// Auto-Aegis
class TargetedAutoSendManager {
    constructor() {
        this.isEnabled = true;  // Always enabled
        this.monitorInterval = null;
        this.lastContent = '';
        this.debugMode = true;
        this.setupMessageListener();
        this.loadSettings();
        this.log('🎯 Auto-Aegis initialized - PERMANENTLY ENABLED');
    }

    log(message) {
        if (this.debugMode) {
            console.log(`[TargetedAutoSend] ${message}`);
        }
    }

    async loadSettings() {
        try {
            // Always enabled, no storage check needed
            this.isEnabled = true;
            this.log('Settings: PERMANENTLY ENABLED');

            // Always start monitoring
            this.startMonitoring();
        } catch (error) {
            this.log('Error in loadSettings: ' + error);
        }
    }

    setupMessageListener() {
        chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
            this.log(`Received message: ${request.action}`);

            if (request.action === 'toggleAutoSend') {
                // Always enable, ignore parameter
                this.toggleMonitoring(true);
                sendResponse({success: true, message: 'Auto-send is permanently enabled'});
            } else if (request.action === 'getStatus') {
                sendResponse({enabled: true, message: 'Permanently enabled'});
            } else if (request.action === 'debugInfo') {
                const debugInfo = this.getDebugInfo();
                sendResponse(debugInfo);
            } else if (request.action === 'testSendButton') {
                this.testSendButton();
                sendResponse({success: true});
            }
            return true;
        });
    }

    toggleMonitoring(enabled) {
        // Always enabled, ignore parameter
        this.isEnabled = true;
        // No storage writes needed

        // Always start monitoring
        this.startMonitoring();
        this.showStatus('🟢 Auto-Send PERMANENTLY ENABLED', 'success');
        this.log('Monitoring started (always on)');

        // Disabling is not allowed
        if (!enabled) {
            this.log('Warning: Attempt to disable ignored - auto-send is permanently enabled');
        }
    }

    startMonitoring() {
        if (this.monitorInterval) {
            clearInterval(this.monitorInterval);
        }

        this.log('Starting targeted monitoring...');

        this.monitorInterval = setInterval(() => {
            this.checkForFunctionResults();
        }, 2000);
    }

    stopMonitoring() {
        if (this.monitorInterval) {
            clearInterval(this.monitorInterval);
            this.monitorInterval = null;
            this.log('Monitoring stopped');
        }
    }

    checkForFunctionResults() {
        try {
            const { input, sendBtn } = this.findChatElements();

            if (!input) {
                if (this.isEnabled) {
                    this.log('Input field not found');
                }
                return;
            }

            const currentContent = this.getInputContent(input);
            const hasFunctionResults = this.detectFunctionResults(currentContent);
            const contentChanged = currentContent !== this.lastContent;
            const sendButtonReady = sendBtn && this.isSendButtonReady(sendBtn);

            this.log(`Content: ${currentContent.length} chars, Function Results: ${hasFunctionResults}, Changed: ${contentChanged}, Send Ready: ${sendButtonReady}`);

            if (contentChanged && hasFunctionResults && sendButtonReady) {
                this.log('🚀 Function results detected - preparing to send...');

                // Wait for typing to complete (2.5 seconds of stability)
                setTimeout(() => {
                    const stableContent = this.getInputContent(input);
                    const { sendBtn: stableSendBtn } = this.findChatElements();
                    if (stableContent === currentContent && stableSendBtn && this.isSendButtonReady(stableSendBtn)) {
                        this.clickSendButton(stableSendBtn);
                    }
                }, 2500);

                this.lastContent = currentContent;
            }

        } catch (error) {
            this.log('Error in checkForFunctionResults: ' + error);
        }
    }

    findChatElements() {
        // Input selectors for DeepSeek
        const inputSelectors = [
            '[contenteditable="true"]',
            '.chat-input',
            'textarea',
            '[role="textbox"]',
            '[data-testid="chat-input"]',
            '.message-input',
            'div[contenteditable]',
            '.ProseMirror',
            '.msg-input',
            'div[data-placeholder*="Message"]'
        ];

        // EXACT DeepSeek send button selector from your CSS
        const sendButtonSelectors = [
            // Primary: Exact selector from your CSS
            '#root > div > div > div.c3ecdb44 > div._7780f2e > div > div._3919b83 > div > div._0f72b0b.ds-scroll-area > div._871cbca > div.aaff8b8f > div > div > div.ec4f5d61 > div.bf38813a > div.ds-icon-button._7436101',
            // Fallback: Just the class combination
            '.ds-icon-button._7436101',
            // Additional fallbacks
            'button[type="submit"]',
            'button:has(svg)',
            'button.ds-icon',
            '.send-button',
            '.submit-button',
            'button[class*="send"]',
            'button[class*="submit"]',
            'button:last-child:has(svg)',
            'button[aria-label*="send"]',
            'button[aria-label*="Send"]',
            'button[title*="send"]',
            'button[title*="Send"]'
        ];

        let input = null;
        let sendBtn = null;

        // Find input
        for (const selector of inputSelectors) {
            const elements = document.querySelectorAll(selector);
            for (const element of elements) {
                if (this.isElementVisible(element)) {
                    input = element;
                    this.log(`Input found with selector: ${selector}`);
                    break;
                }
            }
            if (input) break;
        }

        // Find send button using EXACT selector
        for (const selector of sendButtonSelectors) {
            const elements = document.querySelectorAll(selector);
            for (const element of elements) {
                if (this.isElementVisible(element)) {
                    sendBtn = element;
                    this.log(`Send button found with selector: ${selector}`);

                    // Log detailed info about the button
                    this.log(`Button classes: ${element.className}`);
                    this.log(`Button styles: ${element.style.cssText}`);
                    this.log(`Button attributes: ${Array.from(element.attributes).map(attr => `${attr.name}="${attr.value}"`).join(' ')}`);

                    break;
                }
            }
            if (sendBtn) break;
        }

        return { input, sendBtn };
    }

    getInputContent(input) {
        if (input.contentEditable === 'true') {
            return input.innerText || input.textContent || '';
        } else {
            return input.value || '';
        }
    }

    detectFunctionResults(content) {
        const functionIndicators = [
            'function_result',
            'Function Result',
            '<function_result',
            '```jsonl',
            '{"type": "function_call',
            'call_id',
            'function_call_start',
            'function_call_end',
            'function_result call_id'
        ];

        return functionIndicators.some(indicator =>
            content.includes(indicator)
        );
    }

    isElementVisible(element) {
        if (!element) return false;

        const rect = element.getBoundingClientRect();
        return (
            element.offsetParent !== null &&
            rect.width > 0 &&
            rect.height > 0 &&
            rect.top >= 0 &&
            rect.left >= 0 &&
            rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
            rect.right <= (window.innerWidth || document.documentElement.clientWidth)
        );
    }

    isSendButtonReady(button) {
        if (!button || !this.isElementVisible(button)) {
            return false;
        }

        // Check various disabled states
        const isDisabled = (
            button.disabled ||
            button.style.display === 'none' ||
            button.style.visibility === 'hidden' ||
            button.getAttribute('aria-disabled') === 'true' ||
            button.classList.contains('disabled') ||
            button.hasAttribute('disabled')
        );

        // Special check for DeepSeek button - it might have opacity or other indicators
        const computedStyle = window.getComputedStyle(button);
        const isActuallyVisible = (
            computedStyle.opacity !== '0' &&
            computedStyle.pointerEvents !== 'none' &&
            computedStyle.cursor !== 'not-allowed'
        );

        return !isDisabled && isActuallyVisible;
    }

    clickSendButton(button) {
        try {
            this.log('Attempting to click send button...');
            this.log(`Button details: ${button.outerHTML.substring(0, 300)}`);

            // Method 1: Standard click
            button.click();
            this.log('Standard click attempted');

            // Method 2: Dispatch click event
            const clickEvent = new MouseEvent('click', {
                bubbles: true,
                cancelable: true,
                view: window
            });
            button.dispatchEvent(clickEvent);
            this.log('Click event dispatched');

            // Method 3: Mouse down/up events
            const mouseDown = new MouseEvent('mousedown', { bubbles: true });
            const mouseUp = new MouseEvent('mouseup', { bubbles: true });
            button.dispatchEvent(mouseDown);
            button.dispatchEvent(mouseUp);
            this.log('Mouse events dispatched');

            this.log('✅ Send button click sequence completed!');
            this.showStatus('✅ Function results sent!', 'success');

        } catch (error) {
            this.log('❌ Failed to click send button: ' + error);
            this.showStatus('❌ Failed to send', 'error');
        }
    }

    testSendButton() {
        this.log('=== TESTING SEND BUTTON DETECTION ===');
        const { input, sendBtn } = this.findChatElements();

        if (sendBtn) {
            this.log(`✅ Send button FOUND with exact selector!`);
            this.log(`Button HTML: ${sendBtn.outerHTML.substring(0, 500)}`);
            this.log(`Button classes: ${sendBtn.className}`);
            this.log(`Button ready: ${this.isSendButtonReady(sendBtn)}`);
            this.log(`Computed styles: cursor=${window.getComputedStyle(sendBtn).cursor}, opacity=${window.getComputedStyle(sendBtn).opacity}`);

            // Try to click it
            this.clickSendButton(sendBtn);
        } else {
            this.log('❌ No send button found with any selector');
            this.showStatus('❌ No send button found', 'error');

            // Debug: List all buttons on page
            const allButtons = document.querySelectorAll('button, div[role="button"]');
            this.log(`Found ${allButtons.length} total buttons on page`);
            allButtons.forEach((btn, index) => {
                this.log(`Button ${index}: ${btn.className} - ${btn.outerHTML.substring(0, 200)}`);
            });
        }
    }

    showStatus(message, type = 'info') {
        const statusId = 'targeted-auto-send-status';
        let statusEl = document.getElementById(statusId);

        if (!statusEl) {
            statusEl = document.createElement('div');
            statusEl.id = statusId;
            statusEl.style.cssText = `
                position: fixed;
                top: 10px;
                right: 10px;
                background: #333;
                color: white;
                padding: 8px 12px;
                border-radius: 6px;
                font-size: 12px;
                font-weight: 500;
                z-index: 10000;
                opacity: 0.95;
                box-shadow: 0 2px 8px rgba(0,0,0,0.3);
                max-width: 250px;
                word-wrap: break-word;
            `;
            document.body.appendChild(statusEl);
        }

        // Set color based on type
        if (type === 'success') {
            statusEl.style.background = '#2e7d32';
        } else if (type === 'error') {
            statusEl.style.background = '#c62828';
        } else {
            statusEl.style.background = '#1976d2';
        }

        statusEl.textContent = message;

        // Auto-hide after 3 seconds
        setTimeout(() => {
            if (statusEl && statusEl.textContent === message) {
                statusEl.remove();
            }
        }, 3000);
    }

    getDebugInfo() {
        const { input, sendBtn } = this.findChatElements();
        const currentContent = input ? this.getInputContent(input) : '';

        return {
            enabled: this.isEnabled,
            inputFound: !!input,
            sendButtonFound: !!sendBtn,
            sendButtonReady: sendBtn ? this.isSendButtonReady(sendBtn) : false,
            currentContentLength: currentContent.length,
            hasFunctionResults: this.detectFunctionResults(currentContent),
            url: window.location.href,
            timestamp: new Date().toISOString()
        };
    }
}

// Initialize the targeted auto-send manager
const targetedAutoSendManager = new TargetedAutoSendManager();

// Export for debugging
window.targetedAutoSendManager = targetedAutoSendManager;

// Log initialization
console.log('Extension loaded successfully!');
