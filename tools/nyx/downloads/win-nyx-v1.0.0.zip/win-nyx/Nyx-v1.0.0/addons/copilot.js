import React from 'react';
import ReactDOM from 'react-dom/client';
import { MCPPopover } from '../../components/mcpPopover/mcpPopover';
import { initializeAdapter, } from './common';
function findCopilotButtonInsertionPoint() {
    const footer = document.querySelector('[data-testid="composer-footer-actions"]');
    if (footer)
        return footer;
    const fallback = document.querySelector('textarea + div .flex.items-center.gap-2');
    if (fallback)
        return fallback;
    return null;
}
function insertCopilotButtons(config, stateManager) {
    const container = config.findButtonInsertionPoint();
    if (!container) {
        setTimeout(() => insertCopilotButtons(config, stateManager), 1000);
        return;
    }
    const wrapper = document.createElement('div');
    wrapper.style.viewTransitionName = 'var(--vt-composer-mcp-action)';
    const reactContainer = document.createElement('div');
    reactContainer.id = 'mcp-popover-container';
    reactContainer.className = 'mcp-popover-wrapper';
    reactContainer.style.margin = '0 4px';
    wrapper.appendChild(reactContainer);
    container.appendChild(wrapper);
    ReactDOM.createRoot(reactContainer).render(React.createElement(MCPPopover, {
        toggleStateManager: {
            getState: stateManager.getState.bind(stateManager),
            setMCPEnabled: stateManager.setMCPEnabled.bind(stateManager),
            setAutoInsert: stateManager.setAutoInsert.bind(stateManager),
            setAutoSubmit: stateManager.setAutoSubmit.bind(stateManager),
            setAutoExecute: stateManager.setAutoExecute.bind(stateManager),
            updateUI: stateManager.updateUI.bind(stateManager),
        },
    }));
    stateManager.applyLoadedState();
}
function showCopilotSidebar(adapter) {
    adapter?.showSidebarWithToolOutputs?.() || adapter?.toggleSidebar?.();
}
function hideCopilotSidebar(adapter) {
    adapter?.hideSidebar?.() || adapter?.sidebarManager?.hide?.() || adapter?.toggleSidebar?.();
}
function getCopilotURLKey() {
    const url = window.location.href;
    if (url.includes('/c/'))
        return 'copilot_chat';
    if (url.includes('copilot.microsoft.com'))
        return 'copilot_main';
    return 'copilot_default';
}
const copilotAdapterConfig = {
    adapterName: 'Copilot',
    storageKeyPrefix: 'mcp-copilot-state',
    findButtonInsertionPoint: findCopilotButtonInsertionPoint,
    insertToggleButtons: insertCopilotButtons,
    getStorage: () => localStorage,
    getCurrentURLKey: getCopilotURLKey,
    onMCPEnabled: showCopilotSidebar,
    onMCPDisabled: hideCopilotSidebar,
};
export function initCopilotComponents() {
    const stateManager = initializeAdapter(copilotAdapterConfig);
    window.injectMCPButtons = () => insertCopilotButtons(copilotAdapterConfig, stateManager);
}
