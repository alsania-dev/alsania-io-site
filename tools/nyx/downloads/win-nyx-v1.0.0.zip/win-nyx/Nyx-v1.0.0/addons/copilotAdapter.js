import { BaseAdapter } from './common';
import { logMessage } from '../utils/helpers';
import { insertToolResultToChatInput, attachFileToChatInput, submitChatInput, } from '../components/websites/copilot';
import { SidebarManager } from '../components/sidebar';
import { initCopilotComponents } from './adaptercomponents';
export class CopilotAdapter extends BaseAdapter {
    constructor() {
        super();
        this.name = 'Copilot';
        this.hostname = ['copilot.microsoft.com'];
        this.lastUrl = '';
        this.urlCheckInterval = null;
        this.sidebarManager = SidebarManager.getInstance('copilot');
        logMessage('Created Copilot sidebar manager instance');
    }
    initializeSidebarManager() {
        this.sidebarManager.initialize();
    }
    initializeObserver(forceReset = false) {
        initCopilotComponents();
        if (!this.urlCheckInterval) {
            this.lastUrl = window.location.href;
            this.urlCheckInterval = window.setInterval(() => {
                const currentUrl = window.location.href;
                if (currentUrl !== this.lastUrl) {
                    logMessage(`URL changed from ${this.lastUrl} to ${currentUrl}`);
                    this.lastUrl = currentUrl;
                    initCopilotComponents();
                    this.checkCurrentUrl();
                }
            }, 1000);
        }
    }
    cleanup() {
        if (this.urlCheckInterval) {
            window.clearInterval(this.urlCheckInterval);
            this.urlCheckInterval = null;
        }
        super.cleanup();
    }
    insertTextIntoInput(text) {
        insertToolResultToChatInput(text);
        logMessage(`Inserted text into Copilot input: ${text.substring(0, 20)}...`);
    }
    triggerSubmission() {
        submitChatInput()
            .then((success) => {
                logMessage(`Triggered Copilot form submission: ${success ? 'success' : 'failed'}`);
            })
            .catch((error) => {
                logMessage(`Error triggering Copilot form submission: ${error}`);
            });
    }
    supportsFileUpload() {
        return true;
    }
    async attachFile(file) {
        try {
            const result = await attachFileToChatInput(file);
            return result;
        }
        catch (error) {
            const errorMessage = error instanceof Error ? error.message : String(error);
            logMessage(`Error in adapter when attaching file to Copilot input: ${errorMessage}`);
            console.error('Error in adapter when attaching file to Copilot input:', error);
            return false;
        }
    }
    forceFullScan() {
        logMessage('Forcing full document scan for Copilot');
    }
    checkCurrentUrl() {
        const currentUrl = window.location.href;
        logMessage(`Checking current Copilot URL: ${currentUrl}`);
        if (this.sidebarManager && !this.sidebarManager.getIsVisible()) {
            logMessage('Showing sidebar for Copilot URL');
            this.sidebarManager.showWithToolOutputs();
        }
    }
}
