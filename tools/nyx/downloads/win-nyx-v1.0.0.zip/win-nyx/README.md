# NYX MCP - Windows Setup

## Quick Start

1. **Run `win-setup.bat`** (Right-click → Run as Administrator for best results)
2. **Install Chrome Extension**:
   - Open Chrome, go to `chrome://extensions/`
   - Enable "Developer mode" (top-right toggle)
   - Click "Load unpacked"
   - Select the `chrome-extension` folder from this package
3. **Start NYX**: Double-click `Start NYX.lnk` on your Desktop
4. **Connect**: Click the NYX extension icon in Chrome

## Detailed Steps

### Prerequisites
- **Google Chrome** (version 90+)
- **Node.js 18+** (will be checked during setup)

### What the Setup Script Does
1. **Checks requirements** (Chrome, Node.js)
2. **Creates `C:\Users\[YourUsername]\Desktop\nyx`** directory
3. **Sets up configuration** with restricted filesystem access
4. **Creates start/stop scripts** in the nyx directory
5. **Adds desktop shortcut** `Start NYX.lnk`

### Running the Server
- **Start**: Double-click `Start NYX.lnk` on Desktop (or `nyx-start.bat` in Desktop\nyx\)
- **Stop**: Double-click `nyx-stop.bat` in Desktop\nyx\ (or close the terminal window)

### Security
- Filesystem access is **restricted** to your `Desktop\nyx` directory only
- No access to other parts of your system
- All MCP servers run with minimal permissions

## Troubleshooting

### "Node.js not found"
Download and install Node.js 18+ from [nodejs.org](https://nodejs.org/)

### Chrome Extension Won't Load
- Ensure Chrome is installed
- Enable "Developer mode" in `chrome://extensions/`
- Select the `chrome-extension` **folder** (not a file inside it)

### Server Won't Start
1. Check if Node.js is installed: `node --version`
2. Ensure no other NYX server is running
3. Check firewall allows local connections

## Manual Commands

If scripts don't work, run manually:
```cmd
cd %USERPROFILE%\Desktop\nyx
npx -y @alsania-io/mcpnyx@latest --config config.json --outputTransport streamableHttp
```

## Included Tools
- **Filesystem**: Access files in `Desktop\nyx`
- **Memory Cache**: Store and recall information
- **Playwright**: Browser automation
- **Desktop Commander**: System commands
- **Terminal Controller**: Terminal operations
- **Context7**: Documentation lookup
- **Sequential Thinking**: Problem-solving tool

## Support
For issues, contact the Alsania development team.

---
**NYX MCP** - Sovereign AI infrastructure
*Windows Package v1.0*
